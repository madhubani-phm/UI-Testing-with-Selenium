import junit.framework.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;



public class Unsucessfullylogin {

    @Test

    public void Unsuccessfullogin(){
        System.setProperty(" webdriver.chrome.driver", "C:\\Users\\DELL\\IdeaProjects\\Project04\\src\\test2\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.saucedemo.com/");
        driver.manage().window().maximize();


        WebElement userElement = driver.findElement(By.id("user-name"));
        userElement.sendKeys("admin");
        WebElement passward = driver.findElement(By.id("password"));//Incorrect password
        passward.sendKeys("admin");//Incorrect username
        driver.findElement(By.id("login-button")).click();//Log into the product page

        String expect_msg = "Please Enter the Valid username and password";
        WebElement m = driver.findElement(By.xpath("//*[@class=\"error-message-container error\"]"));
        String act = m.getText();
        System.out.println("Error Message is   : " + act);
        Assert.assertEquals(act,expect_msg);
           driver.quit();

    }



   }









