import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import java.util.List;

public class Cartvalidation {


    @Test

    public static void Cratvalidation(){

        System.setProperty(" webdriver.chrome.driver", "C:\\Users\\DELL\\IdeaProjects\\Project04\\src\\test2\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.saucedemo.com/");
        driver.manage().window().maximize();
        WebElement userElement = driver.findElement(By.id("user-name"));
        userElement.sendKeys("standard_user");
        WebElement passward = driver.findElement(By.id("password"));//Correct password
        passward.sendKeys("secret_sauce");//Correct username
        driver.findElement(By.id("login-button")).click();//Log into the product page

        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();//Add to the cart
        driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a/span")).click();
       // List<WebElement> element = driver.findElements(By.xpath("//*"));
        //System.out.println(Integer.toString((element.size())));

        //for(WebElement el:element)
        //{
           // System.out.println(el.getTagName() +" : " + el.getText());
       // }


        //Page Title display...........................................................................................
        System.out.println("Page Title is   : " + driver.getTitle());
//Remove Button...............................................................................................................
        boolean isDisplayed = driver.findElement(By.id("remove-sauce-labs-backpack")).isDisplayed();
if(isDisplayed){
    System.out.println("Remove button is displayed");
}

else{
    System.out.println("Button is not display");
}
        boolean isEnabled = driver.findElement(By.id("remove-sauce-labs-backpack")).isEnabled();
        if(isEnabled){
            System.out.println("Remove button is enabled");
        }

        else{
            System.out.println("Button is not enabled");
        }
//Chcekout Button.........................................................................................................
boolean isDisplayed1 = driver.findElement(By.id("continue-shopping")).isDisplayed();
        if(isDisplayed1){
            System.out.println("Checkout button is displayed");
        }

        else{
            System.out.println("Remove Button is not displayed");
        }
        boolean isEnabled1 = driver.findElement(By.id("continue-shopping")).isEnabled();
        if(isEnabled1){
            System.out.println("Checkout button is Enabled");
        }

        else{
            System.out.println("Remove Button is not Enabled");
        }



//Continue Shopping button...................................................................................................
        boolean isDisplayed2 = driver.findElement(By.id("continue-shopping")).isDisplayed();
        if(isDisplayed2){
            System.out.println("checkout Button is Displayed");
        }

        else{
            System.out.println("Button is not displayed");
        }
        boolean isEnabled2 = driver.findElement(By.id("continue-shopping")).isEnabled();
        if(isEnabled2){
            System.out.println("checkout Button is Enabled");
        }

        else{
            System.out.println("Button is not Enabled");
        }
// Item price.........................................................................................................
        boolean isDisplayed3= driver.findElement(By.className("inventory_item_price")).isDisplayed();
        if(isDisplayed3){
            System.out.println("Item Price is displayed");
        }

        else{
            System.out.println("Item price is not displayed");
        }

//Inventory Item name..................................................................................................
        boolean isDisplayed4= driver.findElement(By.className("inventory_item_name")).isDisplayed();
        if(isDisplayed4){
            System.out.println("Item Name is displayed");
        }

        else{
            System.out.println("Item Name is not displayed");
        }
//Cart Quantity.........................................................................................................
        boolean isDisplayed5= driver.findElement(By.className("cart_quantity")).isDisplayed();
        if(isDisplayed5){
            System.out.println("Cart Quantity is displayed");
        }

        else{
            System.out.println("Cart Quantity is not displayed");
        }


        //Cart icon.....................................................................................................
        boolean isDisplayed6= driver.findElement(By.className("shopping_cart_link")).isDisplayed();
        if(isDisplayed6){
            System.out.println("Cart Icon is displayed");
        }

        else{
            System.out.println("Cart Icon is not displayed");
        }

//Product details......................................................................................................
        boolean isDisplayed7= driver.findElement(By.className("inventory_item_desc")).isDisplayed();
        if(isDisplayed7){
            System.out.println("Product Details is displayed");
        }

        else{
            System.out.println("Product Details is not displayed");
        }
driver.quit();
    }
}
