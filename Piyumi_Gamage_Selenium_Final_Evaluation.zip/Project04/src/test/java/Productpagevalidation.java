import junit.framework.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Productpagevalidation {
    @Test
    public void Productpagevalidation(){
        System.setProperty(" webdriver.chrome.driver", "C:\\Users\\DELL\\IdeaProjects\\Project04\\src\\test2\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.saucedemo.com/");
        driver.manage().window().maximize();


        //Login...................................................................................................
        WebElement userElement = driver.findElement(By.id("user-name"));
        userElement.sendKeys("standard_user");
        WebElement passward = driver.findElement(By.id("password"));//Correct password
        passward.sendKeys("secret_sauce");//Correct username
        driver.findElement(By.id("login-button")).click();//Log into the product page



        //Page Title display...........................................................................................
        System.out.println("Page Title is   : " + driver.getTitle());

        //Validate the drop dawn.......................................................................................


        //Verify the add cart button....................................................................................
        boolean isDisplayed1 = driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).isDisplayed();
        if(isDisplayed1){
            System.out.println("Backpack image add to cart button is displayed");
        }

        else{
            System.out.println(" Backpack image add to cart Button is not display");
        }

        boolean isDisplayed2 = driver.findElement(By.id("add-to-cart-sauce-labs-bike-light")).isDisplayed();
        if(isDisplayed2){
            System.out.println("Bike-light image add to cart button is displayed");
        }

        else{
            System.out.println(" BBike-light image add to cart Button is not display");
        }

        boolean isDisplayed3 = driver.findElement(By.id("add-to-cart-sauce-labs-bolt-t-shirt")).isDisplayed();
        if(isDisplayed3){
            System.out.println("Bolt T Shirt image add to cart button is displayed");
        }

        else{
            System.out.println(" Bolt T Shirt image add to cart Button is not display");
        }

        boolean isDisplayed4 = driver.findElement(By.id("add-to-cart-sauce-labs-onesie")).isDisplayed();
        if(isDisplayed4){
            System.out.println("Onesie shirt image add to cart button is displayed");
        }

        else{
            System.out.println(" Onesie shirt image add to cart Button is not display");
        }



        //Verify the cart icon.............................................................................................
        boolean isDisplayed5 = driver.findElement(By.className("shopping_cart_link")).isDisplayed();
        if(isDisplayed5){
            System.out.println(" Cart Icon is displayed");
        }

        else{
            System.out.println(" cart Button is not display");
        }

        driver.quit();
    }



}
