import junit.framework.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Unsuccessfullylogin1 {

    @Test
    public void Unsuccessfullylogin1(){
        System.setProperty(" webdriver.chrome.driver", "C:\\Users\\DELL\\IdeaProjects\\Project04\\src\\test2\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.saucedemo.com/");
        driver.manage().window().maximize();

        WebElement userElement = driver.findElement(By.id("user-name"));
        userElement.sendKeys("standard_user");
        WebElement passward = driver.findElement(By.id("password"));//Correct password
        passward.sendKeys("admin");//Correct username

        driver.findElement(By.id("login-button")).click();//Log into the product page
        String expect_msg = "Please Enter the Valid username and password";

        WebElement m = driver.findElement(By.xpath("//*[@data-test=\"error\"]"));
        String act = m.getText();
        System.out.println("Error Message is   : " + act);
        Assert.assertEquals(expect_msg,act);
        driver.quit();

    }
}
