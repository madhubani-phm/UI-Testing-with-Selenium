import junit.framework.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;

import java.util.List;

public class Checkoutproduct {


    @Test

    public void Checkout(){
        WebDriver driver = new ChromeDriver();
        System.setProperty(" webdriver.chrome.driver", "C:\\Users\\DELL\\IdeaProjects\\Project04\\src\\test2\\chromedriver.exe");
        driver.get("https://www.saucedemo.com/");
        driver.manage().window().maximize();
        WebElement userElement = driver.findElement(By.id("user-name"));
        userElement.sendKeys("standard_user");
        WebElement passward = driver.findElement(By.id("password"));//Correct password
        passward.sendKeys("secret_sauce");//Correct username
        driver.findElement(By.id("login-button")).click();//Log into the product page
        //Add to item to the cart
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();//Add to the cart
        driver.findElement(By.className("shopping_cart_badge")).click();//Drive to the cart

        //Checkout the cart
        driver.findElement(By.id("checkout")).click();//Checkout the cart

        //Page Title display...........................................................................................
        System.out.println("Page Title is   : " + driver.getTitle());

        //Fill the form
        WebElement firstname = driver.findElement(By.id("first-name"));//Correct name
        firstname.sendKeys("Piyumi");
        WebElement lastname = driver.findElement(By.id("last-name"));
        lastname.sendKeys("Gamage");
        WebElement postalcode = driver.findElement(By.id("postal-code"));
        postalcode.sendKeys("11640");
        driver.findElement(By.id("continue")).click();//Continue checkout

        //Cancel Button.....................................................................................
        boolean isDisplayed= driver.findElement(By.id("cancel")).isDisplayed();
        if(isDisplayed){
            System.out.println(" Cancel Button is displayed");
        }

        else{
            System.out.println("Cancel Button is not displayed");
        }
        boolean isEnabled = driver.findElement(By.id("cancel")).isEnabled();
        if(isEnabled){
            System.out.println(" Cancel Button is Enabled");
        }

        else{
            System.out.println("Cancel Button is not Enabled");
        }
        //Finish Button..................................................................................................
        boolean isDisplayed1 = driver.findElement(By.id("finish")).isDisplayed();
        if(isDisplayed1){
            System.out.println(" Fisnish Button is Displayed");
        }

        else{
            System.out.println("Finish Button is not Displayed");
        }



        boolean isEnabled2 = driver.findElement(By.id("finish")).isEnabled();
        if(isEnabled2){
            System.out.println(" Cancel Button is Enabled");
        }

        else{
            System.out.println("Cancel Button is not Enabled");
        }


        //Shopping Cart................................................................................................
        boolean isDisplayed2 = driver.findElement(By.xpath("//*[@class=\"shopping_cart_badge\"]")).isDisplayed();
        if(isDisplayed2){
            System.out.println(" Cart Icon is Displayed");
        }

        else{
            System.out.println("Cart Icon is not Displayed");
        }

        //Shipping Information..............................................................................................
        boolean isDisplayed3 = driver.findElement(By.xpath("//*[@class=\"summary_value_label\"]")).isDisplayed();
        if(isDisplayed3){
            System.out.println(" Shipping Information is Displayed");
        }

        else{
            System.out.println("Shipping Information is not Displayed");
        }

        //Item tax...........................................................................................................
        boolean isDisplayed4 = driver.findElement(By.xpath("//*[@class=\"summary_tax_label\"]")).isDisplayed();
        if(isDisplayed4){
            System.out.println(" Item tax is Displayed");
        }

        else{
            System.out.println("Item tax is not Displayed");
        }

        //Item price.........................................................................................................
        boolean isDisplayed5 = driver.findElement(By.xpath("//*[@class=\"inventory_item_price\"]")).isDisplayed();
        if(isDisplayed5){
            System.out.println(" Item Price is Displayed");
        }

        else{
            System.out.println("Item Price is not Displayed");
        }

        //Payment Details.....................................................................................................
        boolean isDisplayed6 = driver.findElement(By.xpath("//*[@class=\"summary_value_label\"]")).isDisplayed();
        if(isDisplayed6){
            System.out.println(" Payment Details is Displayed");
        }

        else{
            System.out.println("Payment Details is not Displayed");
        }

        //Item Total..........................................................................................................
        boolean isDisplayed7 = driver.findElement(By.xpath("//*[@class=\"summary_subtotal_label\"]")).isDisplayed();
        if(isDisplayed7){
            System.out.println(" Item Total is Displayed");
        }

        else{
            System.out.println("Item Total is not Displayed");
        }

        //Total Value Validation...........................................................................................
        String value1 = String.valueOf(driver.findElement(By.xpath("//*[@class=\"inventory_item_price\"]")).getText());
        String value2 = String.valueOf(driver.findElement(By.xpath("//*[@class=\"summary_tax_label\"]")).getText());
        String value3 = String.valueOf(driver.findElement(By.xpath("//*[@class=\"summary_total_label\"]")).getText());

        System.out.println("Tax Value Is :"  + (value2));
        System.out.println("Item Price is : "+ (value1));
        System.out.println("Total Price is : "+ (value3));
        String actual_value = "Total: $32.39";
        Assert.assertEquals(actual_value ,value3);

          driver.findElement(By.id("finish")).click();//Click on the finish button
          driver.quit();

    }


}
