import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Successfullylogin {

    @Test

    public void Successful(){
        System.setProperty(" webdriver.chrome.driver", "C:\\Users\\DELL\\IdeaProjects\\Project04\\src\\test2\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.saucedemo.com/");
        driver.manage().window().maximize();

        //Page Title display...........................................................................................
        System.out.println("Page Title is   : " + driver.getTitle());


        //Validate the fields.............................................................................

        boolean isDisplayed = driver.findElement(By.id("user-name")).isDisplayed();
        if(isDisplayed){
            System.out.println("Username field is displayed");
        }

        else{
            System.out.println(" Username field is not display");
        }
        //Password field is displayed....................................................................................
        boolean isDisplayed1 = driver.findElement(By.id("password")).isDisplayed();
        if(isDisplayed1){
            System.out.println("Password field is displayed");
        }

        else{
            System.out.println(" Password field is not display");
        }

        //Login Button...................................................................................................
        boolean isDisplayed2 = driver.findElement(By.id("login-button")).isDisplayed();
        if(isDisplayed2){
            System.out.println("Login Button is displayed");
        }

        else{
            System.out.println(" Login Button is not display");
        }

        boolean isEnabled = driver.findElement(By.id("login-button")).isEnabled();
        if(isEnabled){
            System.out.println("Login Button is enabled");
        }

        else{
            System.out.println(" Login Button is not enabled");
        }
        //Log in to the product Page......................................................................................
        WebElement userElement = driver.findElement(By.id("user-name"));
        userElement.sendKeys("standard_user");

        WebElement passward = driver.findElement(By.id("password"));//Correct password
        passward.sendKeys("secret_sauce");//Correct username
        driver.findElement(By.id("login-button")).click();//Log into the product page

   driver.quit();

    }

}
